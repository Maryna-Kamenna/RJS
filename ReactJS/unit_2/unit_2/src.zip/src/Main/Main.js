function Main() {
    return (
        <p>Text example</p>)
}

export default Main