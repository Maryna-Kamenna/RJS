
function About() {
    return (
        <>
            About Us
        </>
    );
}

export default About;