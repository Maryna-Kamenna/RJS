function Note(){
  return(
    <div>

    </div>
  )
}
export default Note;