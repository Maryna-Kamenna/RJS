function Error() {
    return (

        < >

        </>

    );
}

export default Error;