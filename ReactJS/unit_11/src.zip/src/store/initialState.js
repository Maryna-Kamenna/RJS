const initialState = {
  users: [
    {
      passport: 'SM748496',
      name: 'Marina',
      age: 32
    },
    {
      passport: 'KM564738',
      name: 'Marusia',
      age: 25
    },
  ],
}

export default initialState;