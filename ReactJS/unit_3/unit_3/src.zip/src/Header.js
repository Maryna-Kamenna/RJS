
function Header() {
    return (
        <>
            <nav>
                <ul>
                    <li><a href="/">Главная</a></li>
                    <li><a href="/about">О сайте</a></li>
                    <li><a href="/cat">Категории</a></li>
                </ul>
            </nav>
        </>
    );
}

export default Header;