function Error() {
    return (
        <h2> 404</h2>
    );
}

export default Error;